import { resolvePartType } from '@/utils/partTypeUtils'
import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { Trash2, Edit2, Check, X } from 'lucide-react'
import { projectsApi } from '@/api/projects'
import { useToast } from '@/context/ToastContext'

interface BOMPartsTableProps {
  parts: any[]
  projectId: number
  isLoading?: boolean
  selectedPartIds: Set<number>
  onToggleSelectPart: (id: number) => void
  onToggleSelectAll: (ids: number[]) => void
  onEditPart: (part: any) => void
  onDeletePart: (partId: number) => void
}

const BOMPartsTable = ({ 
  parts, 
  projectId, 
  isLoading = false,
  selectedPartIds,
  onToggleSelectPart,
  onToggleSelectAll,
  onEditPart,
  onDeletePart 
}: BOMPartsTableProps) => {
  const queryClient = useQueryClient()
  const { showToast } = useToast()
  const [editingCell, setEditingCell] = useState<{ partId: number; field: 'quantity' | 'unit_price' } | null>(null)
  const [tempValue, setTempValue] = useState('')
  const [density, setDensity] = useState<'compact' | 'comfortable'>('comfortable')

  const updatePartMutation = useMutation({
    mutationFn: (payload: { id: number; quantity?: number; unit_price?: number }) =>
      projectsApi.updatePartInSection(payload.id, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['project'] })
      showToast('success', 'Part updated successfully') 
      setEditingCell(null)
    },
    onError: () => showToast('error', 'Failed to update part'),
  })

  const startEditing = (part: any, field: 'quantity' | 'unit_price') => {
    setEditingCell({ partId: part.id, field })
    setTempValue(field === 'quantity' ? part.quantity?.toString() || '' : part.unit_price?.toString() || '')
  }

  const saveEdit = (partId: number) => {
    if (!tempValue || !editingCell) return
    const value = parseFloat(tempValue)
    if (isNaN(value)) return

    const payload = editingCell.field === 'quantity'
      ? { id: partId, quantity: value }
      : { id: partId, unit_price: value }

    updatePartMutation.mutate(payload)
  }

  const cancelEdit = () => setEditingCell(null)

  const toggleSelectAll = () => {
    onToggleSelectAll(parts.map(p => p.id))
  }

  const toggleSelectPart = (id: number) => {
    onToggleSelectPart(id)
  }

  const handleBulkDelete = async () => {
    if (!confirm(`Delete ${selectedPartIds.size} parts?`)) return
    try {
      for (const id of selectedPartIds) {
        await projectsApi.removePartFromSection(id)
      }
      queryClient.invalidateQueries({ queryKey: ['project'] })
      showToast('success', 'Parts deleted')
    } catch (e: any) {
      showToast('error', e.message)
    }
  }

  if (isLoading) {
    return (
      <div className="px-5 py-8 space-y-2">
        <div className="skeleton h-10 w-full rounded-lg" />
        <div className="skeleton h-10 w-full rounded-lg" />
        <div className="skeleton h-10 w-full rounded-lg" />
      </div>
    )
  }

  if (!parts.length) {
    return (
      <div className="px-5 py-12 text-center text-gray-400 text-sm flex flex-col items-center">
        <div className="text-4xl mb-4 bg-gray-50 w-16 h-16 rounded-full flex items-center justify-center border border-gray-100 shadow-inner">📦</div>
        <p className="font-medium">No parts in this subsection yet</p>
      </div>
    )
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center gap-2 h-7">
          {selectedPartIds.size > 0 && (
            <>
              <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">{selectedPartIds.size} selected</span>
              <button onClick={handleBulkDelete} className="text-xs text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 px-2 py-0.5 rounded-md font-medium transition-colors">Bulk Delete</button>
              <button className="text-xs text-primary-600 hover:text-primary-700 bg-primary-50 hover:bg-primary-100 px-2 py-0.5 rounded-md font-medium transition-colors">Add to PO</button>
            </>
          )}
        </div>
        <div className="table-density-toggle">
          <button onClick={() => setDensity('compact')} className={`text-xs px-2 py-1 rounded ${density === 'compact' ? 'bg-slate-200 font-bold' : 'text-slate-500'}`}>Compact</button>
          <button onClick={() => setDensity('comfortable')} className={`text-xs px-2 py-1 rounded ${density === 'comfortable' ? 'bg-slate-200 font-bold' : 'text-slate-500'}`}>Comfortable</button>
        </div>
      </div>
      <div className="responsive-table-wrapper">
        <table className="data-table-modern w-full">
          <thead>
            <tr>
              <th className={`w-10 text-center ${density === 'compact' ? 'py-1' : 'py-3'}`}>
                <input 
                  type="checkbox" 
                  className="rounded border-slate-300 text-primary-600 focus:ring-primary-500 cursor-pointer"
                  checked={parts.length > 0 && parts.every(p => selectedPartIds.has(p.id))}
                  onChange={toggleSelectAll}
                />
              </th>
              <th className={`w-28 text-left px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>Part Ref</th>
              <th className={`text-left px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>Description</th>
              <th className={`w-24 text-left px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>Type</th>
              <th className={`w-20 text-right px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>Qty</th>
              <th className={`w-32 text-right px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>Unit Price</th>
              <th className={`w-32 text-right px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>Total</th>
              <th className={`w-16 px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}></th>
            </tr>
          </thead>
          <tbody className="table-row-stripe">
          {parts.map((part: any) => {
            const { type, ref } = resolvePartType(part)
            const quantity = part.quantity || 0
            const unitPrice = part.unit_price || 0
            const discount = part.discount_percent || 0
            const total = quantity * unitPrice * (1 - (discount / 100))
            const isEditingQty = editingCell?.partId === part.id && editingCell?.field === 'quantity'
            const isEditingPrice = editingCell?.partId === part.id && editingCell?.field === 'unit_price'

            return (
              <tr key={part.id} className="table-row-hover group transition-colors">
                <td className={`text-center ${density === 'compact' ? 'py-1' : 'py-3'}`}>
                  <input 
                    type="checkbox" 
                    className="rounded border-slate-300 text-primary-600 focus:ring-primary-500 cursor-pointer"
                    checked={selectedPartIds.has(part.id)}
                    onChange={() => toggleSelectPart(part.id)}
                  />
                </td>
                <td className={`font-mono text-xs tracking-wider px-6 text-slate-500 ${density === 'compact' ? 'py-1' : 'py-3'}`}>{typeof part.part_ref === 'object' ? part.part_ref?.part_number : part.part_ref || ref}</td>
                <td className={`font-semibold text-navy-900 leading-tight px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>{part.description || part.part_ref?.description}</td>
                <td className={`px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>
                  <span className={`badge-${type.toLowerCase().replace(/[^a-z]/g, '')} px-2.5 py-0.5 rounded-full text-[10px] font-black tracking-tighter`}>
                    {type}
                  </span>
                </td>
                
                {/* Quantity - Inline Editable */}
                <td className={`text-right px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>
                  {isEditingQty ? (
                    <div className="flex items-center justify-end gap-1">
                      <input
                        type="number"
                        value={tempValue}
                        onChange={(e) => setTempValue(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') saveEdit(part.id)
                          if (e.key === 'Escape') cancelEdit()
                        }}
                        className="w-16 text-right border border-primary-400 focus:outline-none focus:border-primary-600 rounded px-2 py-0.5 text-sm m-0"
                        autoFocus
                      />
                      <button onClick={() => saveEdit(part.id)} className="text-emerald-600 hover:bg-emerald-50 rounded p-0.5"><Check className="h-4 w-4" /></button>
                      <button onClick={cancelEdit} className="text-red-500 hover:bg-red-50 rounded p-0.5"><X className="h-4 w-4" /></button>
                    </div>
                  ) : (
                    <span onClick={() => startEditing(part, 'quantity')} className="cursor-pointer hover:text-primary-600 tabular-nums font-bold text-navy-900 border-b border-dashed border-gray-300 transition-colors">
                      {quantity}
                    </span>
                  )}
                </td>

                {/* Unit Price - Inline Editable */}
                <td className={`text-right px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>
                  {isEditingPrice ? (
                    <div className="flex items-center justify-end gap-1">
                      <span className="text-slate-400 text-xs">₹</span>
                      <input
                        type="number"
                        value={tempValue}
                        onChange={(e) => setTempValue(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') saveEdit(part.id)
                          if (e.key === 'Escape') cancelEdit()
                        }}
                        className="w-24 text-right border border-primary-400 focus:outline-none focus:border-primary-600 rounded px-2 py-0.5 text-sm m-0"
                        autoFocus
                      />
                      <button onClick={() => saveEdit(part.id)} className="text-emerald-600 hover:bg-emerald-50 rounded p-0.5"><Check className="h-4 w-4" /></button>
                      <button onClick={cancelEdit} className="text-red-500 hover:bg-red-50 rounded p-0.5"><X className="h-4 w-4" /></button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-end">
                      <span onClick={() => startEditing(part, 'unit_price')} className="cursor-pointer hover:text-primary-600 tabular-nums text-slate-500 text-sm border-b border-dashed border-gray-300 transition-colors">
                        {unitPrice > 0 ? `₹${unitPrice.toLocaleString('en-IN')}` : '—'}
                      </span>
                      {discount > 0 && (
                        <span className="text-[9px] font-black text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-md mt-1 animate-in fade-in slide-in-from-top-1">
                          -{discount}%
                        </span>
                      )}
                    </div>
                  )}
                </td>

                <td className={`text-right font-black tabular-nums text-primary-600 px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>
                  {total > 0 ? `₹${total.toLocaleString('en-IN')}` : '—'}
                </td>
                <td className={`px-6 ${density === 'compact' ? 'py-1' : 'py-3'}`}>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => onEditPart(part)}
                      className="p-1.5 hover:bg-white rounded-lg text-slate-400 hover:text-navy-900 border border-transparent hover:border-slate-100 shadow-sm"
                      title="Edit part details"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => onDeletePart(part.id)}
                      className="p-1.5 hover:bg-red-50 rounded-lg text-red-300 hover:text-red-500 border border-transparent hover:border-red-100 shadow-sm"
                      title="Delete part"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
    </div>
  )
}

export default BOMPartsTable
